export interface Location {
    id: string;
    name: string;
    description: string;
    areas: Area[];
}

export interface Area {
    id: string;
    name: string;
    description: string;
}

export const locations: Location[] = [
    {
        id: 'birmingham',
        name: 'Birmingham',
        description: 'Expert tarmac driveway installation across Birmingham and surrounding areas.',
        areas: [
            {
                id: 'edgbaston',
                name: 'Edgbaston',
                description: 'Premium tarmac driveways for Edgbaston\'s prestigious properties, including both residential and commercial installations.'
            },
            {
                id: 'moseley',
                name: 'Moseley',
                description: 'Specialist tarmac driveway services in Moseley, perfect for Victorian and Edwardian properties.'
            },
            {
                id: 'harborne',
                name: 'Harborne',
                description: 'Professional driveway installations in Harborne, combining durability with aesthetic appeal.'
            },
            {
                id: 'sutton-coldfield',
                name: 'Sutton Coldfield',
                description: 'High-quality tarmac driveways for Sutton Coldfield\'s residential properties.'
            }
        ]
    },
    {
        id: 'wolverhampton',
        name: 'Wolverhampton',
        description: 'Professional tarmac driveway services throughout Wolverhampton.',
        areas: [
            {
                id: 'tettenhall',
                name: 'Tettenhall',
                description: 'Expert driveway installations in Tettenhall, perfect for both modern and traditional homes.'
            },
            {
                id: 'penn',
                name: 'Penn',
                description: 'Quality tarmac driveways for Penn residents, with excellent drainage solutions.'
            },
            {
                id: 'finchfield',
                name: 'Finchfield',
                description: 'Professional driveway services in Finchfield, specializing in residential properties.'
            }
        ]
    },
    {
        id: 'coventry',
        name: 'Coventry',
        description: 'Quality tarmac driveway installations across Coventry.',
        areas: [
            {
                id: 'earlsdon',
                name: 'Earlsdon',
                description: 'Specialist tarmac driveway installations in Earlsdon, perfect for period properties.'
            },
            {
                id: 'styvechale',
                name: 'Styvechale',
                description: 'Professional driveway services in Styvechale, including maintenance and repairs.'
            },
            {
                id: 'allesley',
                name: 'Allesley',
                description: 'Expert tarmac driveway solutions for Allesley\'s residential properties.'
            }
        ]
    },
    {
        id: 'solihull',
        name: 'Solihull',
        description: 'Premium tarmac driveway services in Solihull and surrounding areas.',
        areas: [
            {
                id: 'knowle',
                name: 'Knowle',
                description: 'High-quality driveway installations in Knowle, perfect for luxury homes.'
            },
            {
                id: 'dorridge',
                name: 'Dorridge',
                description: 'Expert tarmac driveway services in Dorridge, including new installations and repairs.'
            },
            {
                id: 'olton',
                name: 'Olton',
                description: 'Professional driveway solutions in Olton, tailored to local properties.'
            }
        ]
    }
];